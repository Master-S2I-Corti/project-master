<footer class="mt-4">
    <div class="container-fluid py-3">
        <div class="row">
            <div class="col-md-6"></div>
            <div class="col-md-3"></div>
            <div class="col-md-3 text-right small align-self-end">©2017 Università di Corsica.</div>
        </div>
    </div>
</footer>